import pika
from flask_sqlalchemy import SQLAlchemy

self.connection = pika.BlockingConnection(pika.ConnectionParameters(host='rmq')
channel = connection.channel()

channel.queue_declare(queue='ReadQ')

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
db = SQLAlchemy(app)
#User class function
class User(db.Model):
    ___tablename__ = 'user'
    uname = db.Column(db.String(50), primary_key=True)
    passwrd = db.Column(db.String(50), primary_key=True)

db.session.commit()
class Ride(db.Model):
	#specify all cols in db 
    __tablename__ = 'ride'
    rideid = db.Column(db.Integer, primary_key=True,autoincrement=True)
    createby = db.Column(db.String(50))
    timestamp = db.Column(db.String(50))
    src = db.Column(db.String(50))
    dest = db.Column(db.String(50))
#user class
class Userr(db.Model):
	#create db.model for userr class
   __tablename__ = "userride"
   rid = db.Column(db.Integer,primary_key=True)
   users = db.Column(db.String(50),primary_key=True)

def functions(data):
    if data["api"] == "delete":
        try:
            u = Ride.query.filter_by(rideid = data["column"]).one()
        except:
            return {"CODE":400,"STATUS":{}}
        return {"CODE":200,"STATUS":{}}
    elif data["api"] == "upcoming":
        list1 = []
        try:
            u = Ride.query.filter(and_(Ride.src == data["src"],Ride.dest == data["dest"])).all()
            names = get("http://CC3-1355526159.us-east-1.elb.amazonaws.com/api/v1/users")
            if names.text == "0":
                return {"CODE":400,"STATUS":{}}
                #return response =400
            for i in u:
                if i.createby in names.text:
                    if datetime.datetime.strptime(i.timestamp,'%d-%m-%Y:%S-%M-%H') >= datetime.datetime.now():
                        p = {}
                        p["rideId"] = i.rideid
                        p["uname"] = i.createby
                        p["timestamp"] = i.timestamp
                        list1.append(p)
                else:
                    return {"CODE":400,"STATUS":{}}
            if list1:
                return {"CODE":204,"STATUS":list1} #200 ok
        except: 
            return {"CODE":204,"STATUS":list1}
    elif data["api"] == "join":
        try:
            ctr1 = Ride.query.filter_by(rideid = data["column1"]).one()
        except:
            return {"CODE":400,"STATUS":{}}
        return {"CODE":200,"STATUS":{}}
        #retrun 400
    elif data["api"]== "clear_db":
        if not (Ride.query.all() or Userr.query.all()):
            return {"CODE":400,"STATUS":{}}
        else:
            return {"CODE":200,"STATUS":{}}
    elif data["api"]== "count":
        counter = db.session.query(func.count(Ride.rideid)).scalar()
        return {"CODE":200,"STATUS":{}}
    if data["api"] == "add":
                try:
                        u = User.query.filter_by(uname = data["un"]).one()
                except:
                        return {"CODE":201,"STATUS":{}}
                return {"CODE":400,"STATUS":{}}
    elif data["api"] == "remove":
                un = data["column"]
                try: #check if it's right
                        u = User.query.filter_by(uname = un).one()
                except:
                        return {"CODE":400,"STATUS":{}}
                return {"CODE":200,"STATUS":{}}
    elif data["api"]== "clear_db":
                if not User.query.all():
                        return {"CODE":400,"STATUS":{}}
                else:
                        return {"CODE":200,"STATUS":{}}
                        #return response=200
    elif data["api"] == "list_users":         #check if try except block is right?/
                try:
                        if not User.query.all():
                                return {"CODE":204,"STATUS":{}}
                        else:
                                v = User.query.all()
                                l=[]
                                for i in v:
                                        l.append(i.username)
                                return {"CODE":200,"STATUS":l}
                except:
                        return {"CODE":400,"STATUS":{}}

def on_request(ch, method, props, body):
    n = body
    response = functions(n)
    ch.basic_publish(exchange='',
                     routing_key=props.reply_to,
                     properties=pika.BasicProperties(correlation_id = \
                                                         props.correlation_id),
                     body=json.dumps(response))
    ch.basic_ack(delivery_tag=method.delivery_tag)

channel.basic_qos(prefetch_count=1)
channel.basic_consume(queue='ReadQ', on_message_callback=on_request)

print(" [x] Awaiting RPC requests")
channel.start_consuming()
