from flask import Flask, request, flash, url_for, redirect, render_template  , jsonify,json,abort,Response
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import pandas as pd
import re
import requests


app = Flask(__name__)  
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///Users.sqlite3' 
app.config['SECRET_KEY'] = "secret key"  
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True

db = SQLAlchemy(app)  
class Users(db.Model):
	ID=db.Column(db.Integer, primary_key = True)
	uname=db.Column(db.String(100),unique=True)
	Password=db.Column(db.String(40),unique=True)

def check(psd):
	if len(psd)>=40:
		if re.match(r'[a-f-A-F-0-9]{,40}',psd):
			return 1
		else:
			return 0
	else:
		return 0
@app.route('/api/v1/db/clear',methods=['POST'])
def clear_db():
	meta=db.metadata
	for table in meta.sorted_tables:
		db.session.execute(table.delete())
	db.session.commit()
	return jsonify()
@app.route('/api/v1/users',methods=['PUT','GET'])
def adduser():
	if(request.method=="PUT"):
		a=request.json.get('username')
		b=request.json.get('password')
		
		if (Users.query.filter_by(uname=a).count() < 1):
			if(check(b)):
				insert_data=str(a)+';'+str(b)
				dr={'insert':str(insert_data),'op':'A'}
				requests.post('http://localhost:5000/api/v1/db/write',json=dr)
				return Response(json.dumps(dict()),status=200)# Call write db
			else:
				return abort(400 ,description="Weak Password!")

		else:
			return abort(400 ,description="User already exists!")
	if(request.method=="GET"):
		if (Users.query.count() >= 1):
			#insert_data=str(str(a)+';'+str(b))
			dr={'op':'H'}
			res=requests.post('http://localhost:5000/api/v1/db/read',json=dr)
			return Response(res,status=200)# Call write db

		else:
			return abort(400 ,description="No users!")
	else:
		return abort(405 ,description="Method doesnot support!")
@app.route('/api/v1/users/<username>',methods=['DELETE'])
def removeUsers(username):
	if(request.method=="DELETE"):
		if (Users.query.filter_by(uname=username).count() >= 1):
			remove_data=username
			dr={'table':'Users','delete':str(remove_data),'op':'B'}
			requests.post('http://localhost:5000/api/v1/db/write',json=dr)
			return Response(json.dumps(dict()),status=200)
		else:
			return abort(400 ,description="User doesnot exist!!")
	else:
		return abort(405 ,description="Method doesnot support!")
@app.route('/api/v1/db/write',methods=['POST'])
def write_db():
	a=request.json.get('op')
	if(a=='A'):
		b=request.json.get('insert')
		c=b.split(';')
		#u=str(request.json.get('insert_data'))
		u=Users(uname=c[0],Password=c[1])
		db.session.add(u)
		db.session.commit()
		return jsonify()
	if(a=='B'):
		data=request.json.get('delete')
		#table=request.json.get('table')
		Users.query.filter_by(uname=str(data)).delete()
		db.session.commit()
		return jsonify()
@app.route('/api/v1/db/read',methods=['POST'])
def read_db():
	a=request.json.get('op')
	if(a=='H'):
		l=[u.uname for u in Users.query.all()]	
		return jsonify(l)

if __name__ == '__main__':
    db.create_all()
    app.run(host="0.0.0.0",debug=True)
		



