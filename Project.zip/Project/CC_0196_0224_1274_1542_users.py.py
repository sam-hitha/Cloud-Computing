from flask import Flask,jsonify,request,Response,make_response
import re
import sqlite3
from requests import post,get
from enum import Enum
import datetime
from sqlalchemy import and_,Integer,String,DateTime,func,Column
from flask_cors import cross_origin
from  flask_sqlalchemy import SQLAlchemy
#till here are the modules
app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
db = SQLAlchemy(app)
#User class function
class User(db.Model):
    ___tablename__ = 'user'
    uname = db.Column(db.String(50), primary_key=True)
    passwrd = db.Column(db.String(50), primary_key=True)
db.session.commit()
ctr=0
@app.route('/api/v1/users',methods=["PUT"])
#1
#this is the add user function
def add_user():
                global ctr
                ctr+=1
                data = request.get_json()
                if re.match(r'[a-fA-F0-9]{40}$',data["passwrd"]):
                        r = post('http://0.0.0.0:80/api/v1/db/read',json={"api":"add","un":data["uname"]})
                        if r.status_code == 201:
                                data["api"] = "add"
                                r1=post('http://0.0.0.0:80/api/v1/db/write',json = data)
                                if(r1.status_code==200):
                                        return jsonify({}),201
                                else:
                                        return jsonify({}),400   #make sure the indentations are proper
                        else:
                                return jsonify({}),400
                else:
                		return jsonify({}),400
"""@app.route('/api/v1/db/read',methods = ["POST"])
#2
#read api 
def read():
        if request.get_json()["api"] == "add":
                try:
                        u = User.query.filter_by(uname = request.get_json()["un"]).one()
                except:
                        return jsonify({}),201
                return jsonify({}),400
        elif request.get_json()["api"] == "remove":
                un = request.get_json()["column"]
                try: #check if it's right
                        u = User.query.filter_by(uname = un).one()
                except:
                        return jsonify({}),400
                return jsonify({}),200
        elif request.get_json()["api"]== "clear_db":
                if not User.query.all():
                        return jsonify({}),400
                else:
                        return jsonify({}),200
                        #return response=200
        elif request.get_json()["api"] == "list_users":         #check if try except block is right?/
                try:
                        if not User.query.all():
                                return Response(status=204)
                        else:
                                v = User.query.all()
                                l=[]
                                for i in v:
                                        l.append(i.username)
                                return jsonify(l),200
                except:
                        return Response(status=400)
@app.route('/api/v1/db/write',methods = ["POST"])   #change this to post method
#3
#api for write db
def write():
	#write api for users.py file
        if request.get_json()["api"] == "remove":
                db.session.delete(User.query.filter_by(uname = request.get_json()["column"]).one())
                db.session.commit()
                return jsonify({}),200
                #write 2 more if statments after this for aa and clear db
        if request.get_json()["api"] == "add":
                db.session.add(User(uname=request.get_json()["uname"],passwrd=request.get_json()["passwrd"]))
                db.session.commit()
                return jsonify({}),200
        if request.get_json()["api"] == "clear_db":
                meta = db.metadata
                for table in reversed(meta.sorted_tables):
                        db.session.execute(table.delete())
                db.session.commit()
                return jsonify({}),200"""
@app.route('/api/v1/users/<uname>',methods = ["DELETE"])  #for method delete
#4
#api to remove users
def remove_user(uname):
	#removing any user from db
                global ctr
                ctr+=1
                r = post('http://0.0.0.0:80/api/v1/db/read',json = {"api":"remove","column":uname})
                #write 2 if blocks to check and return status codes 
                if r.status_code == 400:
                        return jsonify({}),400
                        #return response=400
                elif r.status_code == 200:
                        post('http://0.0.0.0:80/api/v1/db/write',json = {"api":"remove","column":uname})
                        return jsonify({}),200
@app.route('/api/v1/users',methods=['GET'])  #get method
#5
#listing all users
def list_all_users():
	#listing all users in the db
	#first 3 lines similar to previous api
                global ctr
                ctr+=1
                r = post('http://0.0.0.0:80/api/v1/db/read',json ={"api":"list_users"})
                if r.status_code == 200:
                        return jsonify(r.json()),200
                elif r.status_code == 204:
                        return jsonify({}),204
                        #return response=204
                else:
                        return jsonify({}),400
                        #return response=400
@app.route('/api/v1/db/clear',methods=['POST'])  #method is post
#6
#clearing the database
def clear_db():
	#clearing the database 
                r=post('http://34.227.149.172:80/api/v1/db/read',json = {"api":"clear_db"})
                if r.status_code == 200:
                        r1 = post('http://0.0.0.0:80/api/v1/db/write',json = {"api":"clear_db"})
                        if r1.status_code == 200:
                                return jsonify({}),200
                                #return response=200
                        return jsonify({}),400
                        #return response=400
                else:
                        return jsonify({}),200
                        #return response=200
@app.errorhandler(405) #return 405

def clear_db():
	#clearing the database 
                r=post('http://0.0.0.0:80/api/v1/db/read',json = {"api":"clear_db"})
                if r.status_code == 200:
                        r1 = post('http://0.0.0.0:80/api/v1/db/write',json = {"api":"clear_db"})
                        if r1.status_code == 200:
                                return jsonify({}),200
                                #return response=200
                        return jsonify({}),400
                        #return response=400
                else:
                        return jsonify({}),200
                        #return response=200
@app.errorhandler(405) #return 405

#assignment 3 addition
#7
def handle(e):
	#handle a global declaration ctr
    global ctr
    ctr+=1
    return jsonify({}),405
    #return response=405
@app.route('/api/v1/_count',methods = ["GET"])#for method get
#8 
#to count number of http requests
"""
#driver 
if __name__ == '__main__':
        db.create_all()
        app.run(debug=True,host="0.0.0.0",port="80")
"""
def count_req():
        return jsonify([ctr]),200
@app.route('/api/v1/_count',methods = ["DELETE"]) #method delete
#to reset the count to 0
def reset_count():
        global ctr
        ctr=0
        return Response(status=200)
#driver 
if __name__ == '__main__':
        db.create_all()
        app.run(debug=True,host="0.0.0.0",port="80")