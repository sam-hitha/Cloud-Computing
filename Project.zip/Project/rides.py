from flask import Flask,jsonify,request,Response,make_response
import re
import sqlite3
from requests import post,get
from enum import Enum
import datetime
from sqlalchemy import and_,Integer,String,DateTime,func,Column
from  flask_sqlalchemy import SQLAlchemy
from flask_cors import cross_origin
#importing all modules
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
db = SQLAlchemy(app)
#declare class 
class Ride(db.Model):
	#specify all cols in db 
    __tablename__ = 'ride'
    rideid = db.Column(db.Integer, primary_key=True,autoincrement=True)
    createby = db.Column(db.String(50))
    timestamp = db.Column(db.String(50))
    src = db.Column(db.String(50))
    dest = db.Column(db.String(50))
#user class
class Userr(db.Model):
	#create db.model for userr class
   __tablename__ = "userride"
   rid = db.Column(db.Integer,primary_key=True)
   users = db.Column(db.String(50),primary_key=True)
db.session.commit()
ctr=0
#methrd for approute is POST
@app.route('/api/v1/db/read',methods = ["POST"])
#1
#read api for rides
def read():
    if request.get_json()["api"] == "delete":
        try:
            u = Ride.query.filter_by(rideid = request.get_json()["column"]).one()
        except:
            return jsonify({}),400
            #return code=400
        return jsonify({}),200
        #return response =200
    elif request.get_json()["api"] == "upcoming":
        list1 = []
        #write try exception block here
        try:
            u = Ride.query.filter(and_(Ride.src == request.get_json()["src"],Ride.dest == request.get_json()["dest"])).all()
            names = get("http://CC3-1355526159.us-east-1.elb.amazonaws.com/api/v1/users")
            if names.text == "0":
                return jsonify({}),400
                #return response =400
            for i in u:
                if i.createby in names.text:
                    if datetime.datetime.strptime(i.timestamp,'%d-%m-%Y:%S-%M-%H') >= datetime.datetime.now():
                        p = {}
                        p["rideId"] = i.rideid
                        p["uname"] = i.createby
                        p["timestamp"] = i.timestamp
                        list1.append(p)
                else:
                    return jsonify({}),400
                    #return response=400
            if list1:
                return jsonify(list1),200 #200 ok
            return Response(status=204)
        except: #write except block here
            return Response(status=204)
    elif request.get_json()["api"] == "list":
        rid = request.get_json()["rideid"]
        try:
            a1 = Ride.query.filter_by(rideid = rid).one()
            p1={}
            p1["rideId"]=a1.rideid
            p1["createby"]=a1.createby
            v = Userr.query.filter_by(rid = rid).all()
            list1 = []
#write a for loop statement
            for i in v:
                list1.append(i.users)
            p1["users"] = list1
            p1["timestamp"] = a1.timestamp
            #p1["src"] =a1.dest 
            p1["src"] = a1.src
            p1["destination"] = a1.dest
            return jsonify(p1),200
            #200
        except:
            return jsonify({}),204
    elif request.get_json()["api"] == "join":
        try:
            ctr1 = Ride.query.filter_by(rideid = request.get_json()["column1"]).one()
        except:
            return jsonify({}),400
        return jsonify({}),200
        #retrun 400
    elif request.get_json()["api"]== "clear_db":
        if not (Ride.query.all() or Userr.query.all()):
        	#return jsonify({}),200
            return jsonify({}),400
        else:
            return jsonify({}),200
    elif request.get_json()["api"]== "count":
        counter = db.session.query(func.count(Ride.rideid)).scalar()
        return jsonify(counter),200 #200 ok successful 
@app.route('/api/v1/db/clear',methods=['POST']) #post method
#4
#clearing the db
def clear_db():
        r=post('http://0.0.0.0:80/api/v1/db/read',json = {"api":"clear_db"})
        #2 if statements 
        if r.status_code == 200:
        	#stack overflow point 1
            r1 = post('http://0.0.0.0:80/api/v1/db/write',json = {"api":"clear_db"})
            if r1.status_code == 200:
                return jsonify({}),200
            #return jsonify({}),400
            return jsonify({}),400
        else:
        	#retrun jsonify({}),400
            return jsonify({}),200
@app.route('/api/v1/rides',methods = ["GET"])
#add the cross origin statment in mail
@cross_origin(origin = "54.243.2.210")
#5
#list all upcoming rides 
def list_all_upcoming_rides():
        global ctr
        ctr+=1
        src = int(request.args.get('src'))
        dest = int(request.args.get('destination'))
        if src == 0 or dest == 0:
            return jsonify({}),400
        #declare 2 dummy variables
        x = False
        y = False
        if src >=0 and src<=199:
            x = True
        if dest >=0 and dest<=199:
            y = True
        if src == dest:
            return jsonify({}),400
        if not(x and y):
            return jsonify({}),400
            #retrun response =400
        r = post('http://0.0.0.0:80/api/v1/db/read',json = {"api":"upcoming","src":str(src),"dest":str(dest)})
        """
		if src == 0 or dest == 0:
            return jsonify({}),400
        #declare 2 dummy variables
        x = False
        y = False
        """
        if r.status_code == 204:
            return Response(status=204)
        elif r.status_code == 200:
            return r.text
            #retrun r.text jsonify
            #status code 
            #rides method delete
        elif r.status_code == 400:
            return jsonify({}),400
            #retrun 400
@app.route('/api/v1/rides/<rideId>',methods = ["DELETE"])#method delete
#6
#api to delete rides
def delete_ride(rideId):
	#declare ctr as global
        global ctr
        ctr+=1
        r = post('http://0.0.0.0:80/api/v1/db/read',json = {"api":"delete","column":rideId})
        if r.status_code == 200:
            post('http://0.0.0.0:80/api/v1/db/write',json = {"api":"delete","column":rideId})
            return jsonify({}),200
            #return jsonify 200
        else:
            return jsonify({}),400
            #return response=400
@app.route('/api/v1/db/write',methods = ["POST"])#post method
#7
#write api
def write():
    if request.get_json()["api"] == "delete":
        db.session.delete(Ride.query.filter_by(rideid = request.get_json()["column"]).one())
        db.session.commit()
        return jsonify({}),200
        #return response=200
    if request.get_json()["api"] == "remove":
        db.session.delete(User.query.filter_by(uname = request.get_json()["column"]).one())
        db.session.commit()
        return jsonify({}),200
        #return response =200
    if request.get_json()["api"] == "addride":
    	"""
    	if request.get_json()["api"] == "remove":
        db.session.delete(Userr.query.filter_by(uname = request.get_json()["column"]).one())
        db.session.commit()
        return jsonify({}),200
    	"""
        un = request.get_json()["createby"]
        tmp = datetime.datetime.strptime(request.get_json()["timestamp"],'%d-%m-%Y:%S-%M-%H')
        try:
            x = datetime.datetime(tmp.year,tmp.month,tmp.day,tmp.hour,tmp.minute,tmp.second)
        except:
            return jsonify({}),400
        src = request.get_json()["src"]
        dest = request.get_json()["destination"]
        db.session.add(Ride(createby=un,timestamp=request.get_json()["timestamp"],src=src,dest=dest))
        db.session.commit()
        return jsonify({}),201
        #retrun jsonify({}),201
    if request.get_json()["api"] == "join":
        try: #try except block
            rid=request.get_json()["column1"]
            uS=request.get_json()["column2"]
            db.session.add(Userr(rid = rid,users= uS))
            db.session.commit()
        except:
            return jsonify({}),400
        return jsonify({}),200
    if request.get_json()["api"] == "add":
        db.session.add(User(uname=request.get_json()["uname"],passwrd=request.get_json()["passwrd"]))
        db.session.commit()
        return jsonify({}),200
        """
        for table in reversed(meta.sorted_tables):
            db.session.execute(table.delete())
        db.session.commit()
        return jsonify({}),200
        """
    if request.get_json()["api"] == "clear_db":
        meta = db.metadata
        for table in reversed(meta.sorted_tables):
            db.session.execute(table.delete())
        db.session.commit()
        return jsonify({}),200
@app.route('/api/v1/rides',methods=["POST"]) #metod is post
@cross_origin(origin = "54.243.2.210") #cross origin 54.243.2.210
#8
#adding rides 
def add_ride():
        global ctr
        ctr+=1
        data=request.get_json()
        data["api"]="addride"
        #declare dummy variables
        x = False
        y = False
        p = int(data["src"])
        q = int(data["destination"])
        if p>=0 and p<=199:
            x = True
        if q>=0 and q<=199:
            y = True
        if p == q:
            return jsonify({}),400
            #return jsonify({}),400
        if not(x and y) :
            return jsonify({}),400
        uname = request.get_json()["createby"]
        names = get("http://CC3-1355526159.us-east-1.elb.amazonaws.com/api/v1/users")
        if names.text == "0":
            return jsonify({}),400
        if uname in names.text:
            x = post('http://0.0.0.0:80/api/v1/db/write',json = data)
            if x.status_code == 201:
                    return jsonify({}),201
                    #ret
            else:
                    return jsonify({}),400
                    #return jsonify({}),201
        else:
            return jsonify({}),400
@app.route('/api/v1/rides/<rideId>',methods = ["GET"])#method is GET
#9
#list deets
def list_details(rideId):
	#ctr declaration global
        global ctr
        ctr+=1
        r = post('http://0.0.0.0:80/api/v1/db/read',json ={"api":"list","rideid":rideId})
        if r.status_code == 200:
            return jsonify(r.json()),200
        else:#write new else statement
            return jsonify({}),204
@app.route('/api/v1/rides/<rideId>', methods=['POST']) #method is POST
#cross_origin statement 
@cross_origin(origin = "54.243.2.210")
#10
#join rides
def joinride(rideId):
        global ctr
        ctr+=1
        uname = request.get_json()["uname"]
        names = get("http://CC3-1355526159.us-east-1.elb.amazonaws.com/api/v1/users")
        if names.text == "0":
            return jsonify({}),400
        if request.get_json()["uname"] not in names.text:
            return jsonify({}),400
        if datetime.datetime.strptime(ctr1.timestamp,'%d-%m-%Y:%S-%M-%H') < datetime.datetime.now():
            return jsonify({}),400
        r=post('http://0.0.0.0:80/api/v1/db/read',json = {"api":"join","column1":rideId,"column2":uname})
        if r.status_code == 200:
                r1 = post('http://0.0.0.0:80/api/v1/db/write',json = {"api":"join","column1":rideId,"column2":uname})
                if r1.status_code == 200:
                       return Response(status=200)
                       #return response =200 
                return Response(status=400)
                """
                if names.text == "0":
            return jsonify({}),400
        if request.get_json()["uname"] not in names.text:
            return jsonify({}),400
        if datetime.datetime.strptime(ctr1.timestamp,'%d-%m-%Y:%S-%M-%H') < datetime.datetime.now():
            return jsonify({}),400
                """
        else:
                return Response(status=400)
@app.errorhandler(405)#return 405?
#11
#assignement 3
def handle(e):
    global ctr
    ctr+=1
    return jsonify({}),405
@app.route('/api/v1/_count',methods = ["GET"]) #method is get

"""
if __name__ == '__main__':
    db.create_all()
    app.run(debug=True,host="0.0.0.0",port="80")



"""
#count requests
def count_req():
   return jsonify([ctr]),200
@app.route('/api/v1/_count',methods = ["DELETE"])#method delete
#reset count to 0
def reset_count():
   global ctr
   ctr=0
   return Response(status=200)
@app.route('/api/v1/rides/count',methods=["GET"])#method is get
#ridecount r
def ridecount():
   r = post('http://0.0.0.0:80/api/v1/db/read',json={"api":"count"})
   return jsonify([int(r.text)]),200
#driver
if __name__ == '__main__':
    db.create_all()
    app.run(debug=True,host="0.0.0.0",port="80")
