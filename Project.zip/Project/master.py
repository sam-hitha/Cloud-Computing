import pika
from flask_sqlalchemy import SQLAlchemy

self.connection = pika.BlockingConnection(pika.ConnectionParameters(host='rmq')
channel = connection.channel()

channel.queue_declare(queue='WriteQ')

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = True
db = SQLAlchemy(app)
#User class function
class User(db.Model):
    ___tablename__ = 'user'
    uname = db.Column(db.String(50), primary_key=True)
    passwrd = db.Column(db.String(50), primary_key=True)

db.session.commit()
class Ride(db.Model):
	#specify all cols in db 
    __tablename__ = 'ride'
    rideid = db.Column(db.Integer, primary_key=True,autoincrement=True)
    createby = db.Column(db.String(50))
    timestamp = db.Column(db.String(50))
    src = db.Column(db.String(50))
    dest = db.Column(db.String(50))
#user class
class Userr(db.Model):
	#create db.model for userr class
   __tablename__ = "userride"
   rid = db.Column(db.Integer,primary_key=True)
   users = db.Column(db.String(50),primary_key=True)

def functions(data):
        if request.get_json()["api"] == "remove":
                db.session.delete(User.query.filter_by(uname = request.get_json()["column"]).one())
                db.session.commit()
                return {"CODE":200,"STATUS":{}}
                #write 2 more if statments after this for aa and clear db
        if request.get_json()["api"] == "add":
                db.session.add(User(uname=request.get_json()["uname"],passwrd=request.get_json()["passwrd"]))
                db.session.commit()
                return {"CODE":200,"STATUS":{}}
        if request.get_json()["api"] == "clear_db":
                meta = db.metadata
                for table in reversed(meta.sorted_tables):
                        db.session.execute(table.delete())
                db.session.commit()
                return {"CODE":200,"STATUS":{}}
	if request.get_json()["api"] == "delete":
		db.session.delete(Ride.query.filter_by(rideid = request.get_json()["column"]).one())
		db.session.commit()
		return {"CODE":200,"STATUS":{}}
        #return response=200
       if request.get_json()["api"] == "remove":
		db.session.delete(User.query.filter_by(uname = request.get_json()["column"]).one())
		db.session.commit()
		return {"CODE":200,"STATUS":{}}
        #return response =200
       if request.get_json()["api"] == "addride":
		un = request.get_json()["createby"]
		tmp = datetime.datetime.strptime(request.get_json()["timestamp"],'%d-%m-%Y:%S-%M-%H')
		try:
		    x = datetime.datetime(tmp.year,tmp.month,tmp.day,tmp.hour,tmp.minute,tmp.second)
		except:
		    return {"CODE":400,"STATUS":{}}
		src = request.get_json()["src"]
		dest = request.get_json()["destination"]
		db.session.add(Ride(createby=un,timestamp=request.get_json()["timestamp"],src=src,dest=dest))
		db.session.commit()
		return {"CODE":201,"STATUS":{}}

        if request.get_json()["api"] == "join":
		try: #try except block
		    rid=request.get_json()["column1"]
		    uS=request.get_json()["column2"]
		    db.session.add(Userr(rid = rid,users= uS))
		    db.session.commit()
		except:
		    return {"CODE":400,"STATUS":{}}
		return {"CODE":200,"STATUS":{}}
        if request.get_json()["api"] == "add":
		db.session.add(User(uname=request.get_json()["uname"],passwrd=request.get_json()["passwrd"]))
		db.session.commit()
		return {"CODE":200,"STATUS":{}}

        if request.get_json()["api"] == "clear_db":
		meta = db.metadata
		for table in reversed(meta.sorted_tables):
		    db.session.execute(table.delete())
		db.session.commit()
		return {"CODE":200,"STATUS":{}}


def on_request(ch, method, props, body):
    n = body
    response = functions(n)
    ch.basic_publish(exchange='',
                     routing_key=props.reply_to,
                     properties=pika.BasicProperties(correlation_id = \
                                                         props.correlation_id),
                     body=json.dumps(response))
    ch.basic_ack(delivery_tag=method.delivery_tag)

channel.basic_qos(prefetch_count=1)
channel.basic_consume(queue='WriteQ', on_message_callback=on_request)

print(" [x] Awaiting RPC requests")
channel.start_consuming()
