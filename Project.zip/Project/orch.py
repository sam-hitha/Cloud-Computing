import pika
import uuid
import threading
from time import sleep
from flask import Flask

app = Flask(__name__)

class Orchestrator(object):
	def __init__(self,queue,call_queue=result.method.queue):
        	self.connection = pika.BlockingConnection(pika.ConnectionParameters(host='rmq'))
	        self.channel = self.connection.channel()
		self.rpc_queue = queue
	        result = self.channel.queue_declare(exclusive=True)
	        self.callback_queue = call_queue
	        self.channel.basic_consume(
                queue=self.callback_queue,
                on_message_callback=self.on_response,auto_ack=True)
		self.channel.start_consuming()
	
	def on_response(self, ch, method, props, body):
        	if self.corr_id == props.correlation_id:
        	    self.response = body 
	def call(self, n):
        	self.response = None
        	self.corr_id = str(uuid.uuid4())
        	self.channel.basic_publish(
            	exchange='',
            	routing_key=self.rpc_queue,
            	properties=pika.BasicProperties(
                	reply_to=self.callback_queue,
                	correlation_id=self.corr_id,
            	),
            	body=n)
        while self.response is None:
            self.connection.process_data_events()
	self.connection.close()
        return jsonify(self.response)

@app.route('/api/v1/db/write',methods = ["POST"])
def write():
	data=request.get_json()
	if data["api"]== "remove":
		orch=Orchestrator('WriteQ')
		res=orch.call(json.dumps(data))
		return Response(res,status=res['CODE'])
	elif data["api"]== "add":
		orch=Orchestrator('WriteQ')
		res=orch.call(json.dumps(data))
		return Response(res,status=res['CODE'])
	elif data["api"]== "delete":
		orch=Orchestrator('WriteQ')
		res=orch.call(json.dumps(data))
		return Response(res,status=res['CODE'])
	if data["api"] == "clear_db":
		'''
                meta = db.metadata
                for table in reversed(meta.sorted_tables):
                        db.session.execute(table.delete())
                db.session.commit()'''
		orch=Orchestrator('WriteQ')
		res=orch.call(json.dumps(data))
		return Response(res,status=res['CODE'])
                
    	if data["api"] == "addride":
		un = data["createby"]
		tmp = datetime.datetime.strptime(data["timestamp"],'%d-%m-%Y:%S-%M-%H')
		try:
		    x = datetime.datetime(tmp.year,tmp.month,tmp.day,tmp.hour,tmp.minute,tmp.second)
		except:
		    return jsonify({}),400
		src = data["src"]
		dest = data["destination"]
		data={"createby":un,"timestamp":data["timestamp"],"src":src,"dest":dest}
		orch=Orchestrator('WriteQ')
		res=orch.call(json.dumps(data))
		return Response(res,status=res['CODE'])
        if data["api"] == "join":
		try: #try except block
			orch=Orchestrator('WriteQ')
			res=orch.call(json.dumps(data))
			return Response(res,status=res['CODE'])
		except:
		    return jsonify({}),400
		return jsonify({}),200

@app.route('/api/v1/db/read',methods = ["POST"])
def read():
	data=request.get_json()
	if data["api"]== "upcoming":
		orch=Orchestrator('ReadQ','ResponseQ')
		res=orch.call(json.dumps(data))
		return Response(res,status=res['CODE'])
	elif data["api"]== "list":
		orch=Orchestrator('ReadQ','ResponseQ')
		res=orch.call(json.dumps(data))
		return Response(res,status=res['CODE'])
	elif data["api"]== "list_users":
		orch=Orchestrator('ReadQ','ResponseQ')
		res=orch.call(json.dumps(data))
		return Response(res,status=res['CODE'])

if __name__ == '__main__':    
    app.run()

